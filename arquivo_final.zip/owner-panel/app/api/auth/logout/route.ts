import { NextResponse } from "next/server";

export async function POST() {
  const response = NextResponse.json({ ok: true });
  response.cookies.delete("miyora_owner_session");
  response.cookies.delete("miyora_owner_oauth_state");
  return response;
}
