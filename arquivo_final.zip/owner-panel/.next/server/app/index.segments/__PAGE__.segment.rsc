1:"$Sreact.fragment"
2:I[1133,[],""]
3:I[4297,[],""]
7:"static/chunks/568-66e5f4bdc1fba52f.js"
8:"static/chunks/app/page-57a2aa1aa5686ac5.js"
9:I[9568,["568","$7","974","$8"],""]
a:I[1872,[],"OutletBoundary"]
b:"$Sreact.suspense"
e:"ViewportBoundary"
f:I[1872,[],"$e"]
10:"MetadataBoundary"
11:I[1872,[],"$10"]
:HL["/_next/static/css/274cc0d19564733a.css","style"]
5:X
6:[["children",{"s":"__PAGE__","h":160,"d":{"r":["$","$1","c",{"children":[["$","main",null,{"className":"login-screen","children":["$","section",null,{"className":"login-card","children":[["$","span",null,{"className":"brand-mark","children":"M"}],["$","p",null,{"className":"eyebrow","children":"Central Miyora"}],["$","h1",null,{"children":"Área privada do proprietário"}],["$","p",null,{"children":"Autenticação exclusiva pelo Discord configurado no ambiente administrativo."}],["$","a",null,{"className":"primary-button","href":"/api/auth/discord","children":"Entrar com Discord"}],["$","$L9",null,{"className":"text-link","href":"/api/health","children":"Verificar status da API"}]]}]}],null,["$","$La",null,{"children":["$","$b",null,{"name":"Next.MetadataOutlet","children":"$@c"}]}]]}],"p":"$@d","v":null,"s":"$5"}}]]
0:{"t":{"t":{"s":"","h":80,"d":{"r":["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/css/274cc0d19564733a.css","precedence":"next"}]],["$","html",null,{"lang":"pt-BR","suppressHydrationWarning":true,"children":["$","body",null,{"children":[["$","script",null,{"dangerouslySetInnerHTML":{"__html":"try{document.documentElement.dataset.theme=localStorage.getItem('miyora-owner-theme')||'light'}catch(e){}"}}],["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}],"notFound":[[["$","title",null,{"children":"404: This page could not be found."}],["$","div",null,{"style":{"fontFamily":"system-ui,\"Segoe UI\",Roboto,Helvetica,Arial,sans-serif,\"Apple Color Emoji\",\"Segoe UI Emoji\"","height":"100vh","textAlign":"center","display":"flex","flexDirection":"column","alignItems":"center","justifyContent":"center"},"children":["$","div",null,{"children":[["$","style",null,{"dangerouslySetInnerHTML":{"__html":"body{color:#000;background:#fff;margin:0}.next-error-h1{border-right:1px solid rgba(0,0,0,.3)}@media (prefers-color-scheme:dark){body{color:#fff;background:#000}.next-error-h1{border-right:1px solid rgba(255,255,255,.3)}}"}}],["$","h1",null,{"className":"next-error-h1","style":{"display":"inline-block","margin":"0 20px 0 0","padding":"0 23px 0 0","fontSize":24,"fontWeight":500,"verticalAlign":"top","lineHeight":"49px"},"children":404}],["$","div",null,{"style":{"display":"inline-block"},"children":["$","h2",null,{"style":{"fontSize":14,"fontWeight":400,"lineHeight":"49px","margin":0},"children":"This page could not be found."}]}]]}]}]],[]]}]]}]}]]}],"p":"$@4","v":null,"s":"$5"},"c":"$Q6"},"h":{"r":["$","$1","h",{"children":[null,["$","$Lf",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]}],["$","$L11",null,{"children":[["$","div",null,{"hidden":true,"children":["$","$b",null,{"name":"Next.Metadata","children":[]}]}],null]}],null]}],"p":"$@12","v":null,"s":"$5"}},"a":"$@13","u":"$@14","b":"7zFKpsYeECTlVf7NNMh01"}
c:null
5:300
14:true
5:C
13:0
4:"$undefined"
12:"$undefined"
d:"$undefined"
