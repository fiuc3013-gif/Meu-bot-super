import os
from logging.config import fileConfig

from alembic import context
from sqlalchemy import engine_from_config, pool

from shared.database.base import Base
from shared.database import models  # noqa: F401

config = context.config
if config.config_file_name:
    fileConfig(config.config_file_name)

configured_url = os.getenv("DATABASE_URL", "")
if not configured_url:
    raise RuntimeError("DATABASE_URL deve apontar para o PostgreSQL central do Neon")
config.set_main_option("sqlalchemy.url", configured_url)

target_metadata = Base.metadata


def run_migrations_offline() -> None:
    context.configure(url=configured_url, target_metadata=target_metadata, literal_binds=True)
    with context.begin_transaction():
        context.run_migrations()


def run_migrations_online() -> None:
    connectable = engine_from_config(
        config.get_section(config.config_ini_section, {}),
        prefix="sqlalchemy.",
        poolclass=pool.NullPool,
    )
    with connectable.connect() as connection:
        context.configure(connection=connection, target_metadata=target_metadata)
        with context.begin_transaction():
            context.run_migrations()


if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
