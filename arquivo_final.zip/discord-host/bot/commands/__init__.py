"""Comandos gerais do Miyora."""
