1:"$Sreact.fragment"
2:I[1133,[],""]
3:I[4297,[],""]
a:"static/chunks/568-66e5f4bdc1fba52f.js"
b:"static/chunks/app/adicionar/page-a31a1fa5d06b0b48.js"
c:I[9568,["568","$a","331","$b"],""]
d:I[1872,[],"OutletBoundary"]
e:"$Sreact.suspense"
11:"ViewportBoundary"
12:I[1872,[],"$11"]
13:"MetadataBoundary"
14:I[1872,[],"$13"]
:HL["/_next/static/css/7b1e5c0442f5759f.css","style"]
5:X
8:X
8:C
9:[["children",{"s":"__PAGE__","h":160,"d":{"r":["$","$1","c",{"children":[["$","div",null,{"className":"site-shell","children":[["$","header",null,{"className":"topbar","children":[["$","$Lc",null,{"className":"brand","href":"/","children":[["$","span",null,{"className":"brand-mark","children":"M"}],["$","span",null,{"children":"Miyora"}]]}],["$","nav",null,{"className":"topnav","children":[["$","$Lc",null,{"href":"/sobre","children":"Sobre"}],["$","$Lc",null,{"href":"/dashboard","children":"Gerenciar"}]]}]]}],["$","main",null,{"className":"content-page","children":["$","div",null,{"className":"empty-state","children":[["$","p",null,{"className":"eyebrow","children":"Convite oficial"}],["$","h1",null,{"children":"Adicione o Miyora ao seu servidor"}],["$","p",null,{"children":"O link solicita apenas permissões básicas necessárias para presença e respostas. O conjunto pode crescer somente em etapas futuras autorizadas."}],["$","p",null,{"className":"notice","children":"Configure `DISCORD_CLIENT_ID` ou `DISCORD_INVITE_URL` no ambiente Vercel."}]]}]}]]}],null,["$","$Ld",null,{"children":["$","$e",null,{"name":"Next.MetadataOutlet","children":"$@f"}]}]]}],"p":"$@10","v":null,"s":"$5"}}]]
6:[["children",{"s":"adicionar","h":96,"d":{"r":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"p":"$@7","v":"$8","s":"$5"},"c":"$Q9"}]]
0:{"t":{"t":{"s":"","h":80,"d":{"r":["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/css/7b1e5c0442f5759f.css","precedence":"next"}]],["$","html",null,{"lang":"pt-BR","suppressHydrationWarning":true,"children":["$","body",null,{"children":[["$","script",null,{"dangerouslySetInnerHTML":{"__html":"try{document.documentElement.dataset.theme=localStorage.getItem('miyora-theme')||'light'}catch(e){}"}}],["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}],"notFound":[[["$","title",null,{"children":"404: This page could not be found."}],["$","div",null,{"style":{"fontFamily":"system-ui,\"Segoe UI\",Roboto,Helvetica,Arial,sans-serif,\"Apple Color Emoji\",\"Segoe UI Emoji\"","height":"100vh","textAlign":"center","display":"flex","flexDirection":"column","alignItems":"center","justifyContent":"center"},"children":["$","div",null,{"children":[["$","style",null,{"dangerouslySetInnerHTML":{"__html":"body{color:#000;background:#fff;margin:0}.next-error-h1{border-right:1px solid rgba(0,0,0,.3)}@media (prefers-color-scheme:dark){body{color:#fff;background:#000}.next-error-h1{border-right:1px solid rgba(255,255,255,.3)}}"}}],["$","h1",null,{"className":"next-error-h1","style":{"display":"inline-block","margin":"0 20px 0 0","padding":"0 23px 0 0","fontSize":24,"fontWeight":500,"verticalAlign":"top","lineHeight":"49px"},"children":404}],["$","div",null,{"style":{"display":"inline-block"},"children":["$","h2",null,{"style":{"fontSize":14,"fontWeight":400,"lineHeight":"49px","margin":0},"children":"This page could not be found."}]}]]}]}]],[]]}]]}]}]]}],"p":"$@4","v":null,"s":"$5"},"c":"$Q6"},"h":{"r":["$","$1","h",{"children":[null,["$","$L12",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]}],["$","$L14",null,{"children":[["$","div",null,{"hidden":true,"children":["$","$e",null,{"name":"Next.Metadata","children":[]}]}],null]}],null]}],"p":"$@15","v":null,"s":"$5"}},"a":"$@16","u":"$@17","b":"Sg5eCGwSvmIYvEGlywtua"}
f:null
5:300
17:true
5:C
16:0
7:"$undefined"
4:"$undefined"
15:"$undefined"
10:"$undefined"
